


from newsapi import NewsApiClient
import requests
import pandas as pd



key  = "889c9d2b4fd34946b52e4f5106f1735e"
url="https://newsapi.org/v2/top-headlines?sources=bbc-news&apiKey=889c9d2b4fd34946b52e4f5106f1735e"


def news():
    title=[]
    urla=[]
    url="https://newsapi.org/v2/top-headlines?sources=bbc-news&apiKey=889c9d2b4fd34946b52e4f5106f1735e"
    news=requests.get(url).json()
    article=news["articles"]
    for i in article:
        # print(i["title"])
        title.append(i["title"])
        urla.append(i["url"])

    return pd.DataFrame(title,columns=["Title"])
    
