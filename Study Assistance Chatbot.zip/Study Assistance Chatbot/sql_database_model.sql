create database chatbot;
use chatbot;




create table unique_employees(
emp_id int primary key  auto_increment,
emp_name varchar(50) , 
emp_email varchar(50) unique , 
password varchar(50), mobile_number varchar(10),
emp_hobby varchar(50) ,emp_age int );

insert into unique_employees values(1,"rajendra","raj@gmail.com","raj","9983166632","Comedy","25");

create table user_history(
emp_id int , emp_email varchar(50), emp_subject varchar(100) , emp_query varchar(10000), date_time timestamp default now() ,
FOREIGN KEY (emp_id) REFERENCES unique_employees(emp_id));

create table user_marks_details(emp_id int , emp_marks int , foreign key (emp_id) references unique_employees(emp_id));
insert into user_marks_details values(1,50);



truncate table unique_employees;
truncate table user_history;
drop table unique_employees;
drop table user_history;
drop table user_marks_details;

use chatbot;
select * from unique_employees;
select * from user_history;	
desc user_history;



drop table user_marks_details;
create table user_marks_details(emp_id int , emp_marks int , foreign key (emp_id) references unique_employees(emp_id));
insert into user_marks_details values(5,30);
select * from user_marks_details;



-- truncate table unique_employees; 


