import google.generativeai as genai
import textwrap
from IPython.display import display
from IPython.display import Markdown


genai.configure(api_key="AIzaSyAHiCu34AQ9yabPeDkAAq4VE2fDqRnAZlA")
model = genai.GenerativeModel('gemini-pro')
def TextGenerator(full_prompt):
    response = model.generate_content(full_prompt)
    print(full_prompt)
    return response.text
